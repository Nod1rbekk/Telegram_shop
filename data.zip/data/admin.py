from aiogram import Bot, Dispatcher, types
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils import executor
import pandas as pd
import logging

# Bot token
TOKEN = "7005215690:AAFUSvnGm3YuSf_-0k4TDfqPuC3mfai4drU"  # Bot tokeningizni kiriting

# Initialize bot and dispatcher
bot = Bot(token=TOKEN)
dp = Dispatcher(bot)

# CSV file paths
USER_DATA_FILE = "data/users.csv"
PROMO_CODES_FILE = "data/promocodes.csv"

# Logging configuration
logging.basicConfig(level=logging.INFO)

# Admin menu buttons
admin_menu = ReplyKeyboardMarkup(resize_keyboard=True)
admin_menu.add(KeyboardButton("Foydalanuvchilar ro'yxati"))
admin_menu.add(KeyboardButton("Promo kod qo'shish"))
admin_menu.add(KeyboardButton("Orqaga"))

# Helper functions
def load_user_data():
    return pd.read_csv(USER_DATA_FILE)

def save_user_data(df):
    df.to_csv(USER_DATA_FILE, index=False)

def load_promocodes():
    return pd.read_csv(PROMO_CODES_FILE)

def save_promocodes(df):
    df.to_csv(PROMO_CODES_FILE, index=False)


@dp.message_handler(commands=["admin"])
async def admin_handler(message: types.Message):
    # Admin ID tekshiruvini olib tashladik
    await message.reply("Admin panelga xush kelibsiz!", reply_markup=admin_menu)


@dp.message_handler(lambda message: message.text == "Foydalanuvchilar ro'yxati")
async def list_users_handler(message: types.Message):
    df = load_user_data()
    if df.empty:
        await message.reply("Foydalanuvchilar ro'yxati bo'sh.")
    else:
        user_list = "Foydalanuvchilar ro'yxati:\n"
        for _, row in df.iterrows():
            user_list += f"ID: {row['user_id']}, Ism: {row['name']}, Coinlar: {row['coins']}, Referral: {row['referrals']}\n"
        await message.reply(user_list)


@dp.message_handler(lambda message: message.text == "Promo kod qo'shish")
async def add_promocode_handler(message: types.Message):
    await message.reply("Yangi promo kodni kiriting (namuna: KOD,10):", reply_markup=types.ForceReply())


@dp.message_handler(
    lambda message: message.reply_to_message and "Yangi promo kodni kiriting" in message.reply_to_message.text)
async def save_promocode_handler(message: types.Message):
    try:
        promocode, coins = message.text.split(",")
        coins = int(coins.strip())

        df = load_promocodes()
        new_code = pd.DataFrame([{"promo_code": promocode.strip(), "coins": coins}])
        df = pd.concat([df, new_code], ignore_index=True)
        save_promocodes(df)

        await message.reply(f"Promo kod saqlandi: {promocode} ({coins} coin).", reply_markup=admin_menu)
    except Exception as e:
        logging.error(f"Promo kodni saqlashda xatolik: {e}")
        await message.reply("Xatolik yuz berdi. Formatingizni tekshiring (KOD,10).", reply_markup=admin_menu)


@dp.message_handler(lambda message: message.text == "Orqaga")
async def back_to_main_menu_handler(message: types.Message):
    await message.reply("Orqaga qaytdingiz.", reply_markup=admin_menu)


if __name__ == "__main__":
    executor.start_polling(dp, skip_updates=True)
